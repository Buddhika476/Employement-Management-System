package com.crudwithreact.springbootandreactcrud.config;

public class JwtConstant {
    public static final String SECRET_KEY="hdgfhddhcbdnvfdgreurteufhednjkfiowruerfgeydbsdjcioswrfeiufhdjf";
    public static final String JWT_HEADER="Authorization";
}
